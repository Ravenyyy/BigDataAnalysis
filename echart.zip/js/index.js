// 心理测询
(function () {
  // 实例化对象
  var myChart = echarts.init(document.querySelector("#heart"));
  // 指定配置和数据
  var option = {
    // color: ["#2f89cf"],
    color: ["#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94"],

    tooltip: {
      trigger: "axis",
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
        crossStyle: {
          color: '#999'
        }
      }
    },
    legend: {
      right: "10%",
      // data: ['测询人次', '异常人次', '测询占比']
      textStyle: {
        color: "#4c9bfd"
      }
    },
    grid: {
      left: "0%",
      top: "10px",
      right: "0%",
      bottom: "4%",
      containLabel: true
    },
    xAxis: [{
      type: "category",
      boundaryGap: false,
      data: [
        "一支队",
        "二支队",
        "三支队",
        "四支队",
        "五支队",
        "六支队",
        "七支队",
        "八支队",
        "九支队",
        "十支队",
        "十一支队",
        "十二支队"
      ],
      // axisTick: {
      //   alignWithLabel: true
      // },
      axisLabel: {
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: "12"
        }
      },
      axisLine: {
        show: false
      }
    }],
    yAxis: [{
        type: "value",
        name: "人次",
        min: 0,
        max: 250,
        interval: 50,
        axisLabel: {
          textStyle: {
            color: "rgba(255,255,255,.6)",
            fontSize: "12"
          }
        },
        axisLine: {
          lineStyle: {
            color: "rgba(255,255,255,.1)"
            // width: 1,
            // type: "solid"
          }
        },
        splitLine: {
          lineStyle: {
            color: "rgba(255,255,255,.1)"
          }
        }
      },
      {
        type: "value",
        name: "百分比",
        min: 0,
        max: 100,
        interval: 20,
        axisLabel: {
          textStyle: {
            color: "rgba(255,255,255,.6)",
            fontSize: "12",
          },
          formatter: '{value}%'
        },
        axisLine: {
          lineStyle: {
            color: "rgba(255,255,255,.1)"
            // width: 1,
            // type: "solid"
          }
        },
        splitLine: {
          lineStyle: {
            color: "rgba(255,255,255,.1)"
          }
        }
      }
    ],
    series: [{
        name: '测询人次',
        type: 'bar',
        barWidth: "35%",
        data: [22, 49, 70, 23, 26, 77, 136, 162, 6, 20, 64, 33]
      },
      {
        name: '异常人次',
        type: 'bar',
        barWidth: "35%",
        data: [6, 9, 9, 4, 7, 7, 6, 2, 7, 8, 6, 3]
      },
      {
        name: '测询占比',
        type: 'line',
        yAxisIndex: 1,
        data: [3.2, 7.1, 10.2, 3.3, 3.8, 11.2, 19.8, 23.4, 1, 2.9, 9.3, 4.8]
      }
    ]
  };

  // 把配置给实例对象
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });

})();

//智慧营区1
(function () {
  // 实例化对象
  var myChart = echarts.init(document.querySelector("#smart_1"));
  // 指定配置和数据
  var option = {
    // color: ["#2f89cf"],
    color: ["#ff9d6f", "#00f2f1"],

    tooltip: {
      trigger: "axis",
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
        crossStyle: {
          color: '#999'
        }
      }
    },
    legend: {
      right: "5%",
      textStyle: {
        color: "#4c9bfd",
        fontSize: "10"
      }
    },
    grid: {
      left: "0%",
      top: "10px",
      right: "0%",
      bottom: "4%",
      containLabel: true
    },
    xAxis: [{
      type: "category",
      boundaryGap: false,
      data: [
        "一支队",
        "二支队",
        "三支队",
        "四支队",
        "五支队",
        "六支队",
        "七支队",
        "八支队",
        "九支队",
        "十支队",
        "十一支队",
        "十二支队"
      ],
      // axisTick: {
      //   alignWithLabel: true
      // },
      axisLabel: {
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: "12"
        }
      },
      axisLine: {
        show: false
      }
    }],
    yAxis: [{
      type: "value",
      name: "人次",
      min: 0,
      max: 100,
      interval: 20,
      axisLabel: {
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: "12"
        }
      },
      axisLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)"
          // width: 1,
          // type: "solid"
        }
      },
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)"
        }
      }
    }],
    series: [{
        name: '手机违规使用次数',
        type: 'bar',
        barWidth: "35%",
        data: [22, 49, 70, 23, 26, 77, 66, 12, 6, 20, 64, 33]
      },
      {
        name: '危险驾驶总次数',
        type: 'bar',
        barWidth: "35%",
        data: [6, 9, 9, 14, 7, 7, 6, 21, 7, 8, 6, 3]
      }
    ]
  };

  // 把配置给实例对象
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });

})();


// 智慧营区2
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#smart_2"));

  option = {
    title: {
      text: '综合睡眠质量统计结果',
      textStyle: {
        color: "#ffffff",
        fontSize: 10
      },
      left: 'center',
      bottom: 0
    },
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      position: function (p) {
        //其中p为当前鼠标的位置
        return [p[0] + 10, p[1] - 10];
      }
    },
    // legend: {
    //   orient: 'vertical',
    //   left: 10,
    //   data: ['良好', '一般', '较差']
    // },
    series: [{
      name: "睡眠质量",
      type: "pie",
      center: ["50%", "42%"],
      radius: ["50%", "70%"],
      color: [
        "#00f2f1", "#ed3f35", "#FFFF00", "#4EEE94"
      ],
      label: {
        show: false
      },
      labelLine: {
        show: false
      },
      data: [{
          value: 576,
          name: "良好"
        },
        {
          value: 265,
          name: "一般"
        },
        {
          value: 144,
          name: "较差"
        }
      ]
    }]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();

//智慧营区3
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#smart_3"));

  // 2. 指定配置和数据
  var option = {

    color: ["#4EEE94"],
    tooltip: {
      // 通过坐标轴来触发
      trigger: "axis"
    },
    // legend: {
    //   // 距离容器10%
    //   right: "10%",
    //   // 修饰图例文字的颜色
    //   textStyle: {
    //     color: "#4c9bfd"
    //   }
    //   // 如果series 里面设置了name，此时图例组件的data可以省略
    //   // data: ["邮件营销", "联盟广告"]
    // },
    grid: {
      top: "20%",
      left: "3%",
      right: "4%",
      bottom: "3%",
      show: true,
      borderColor: "#012f4a",
      containLabel: true
    },

    xAxis: {
      type: "category",
      boundaryGap: false,
      data: [
        "一支队",
        "二支队",
        "三支队",
        "四支队",
        "五支队",
        "六支队",
        "七支队",
        "八支队"
      ],
      // 去除刻度
      axisTick: {
        show: false
      },
      // 修饰刻度标签的颜色
      axisLabel: {
        color: "rgba(255,255,255,.7)"
      },
      // 去除x坐标轴的颜色
      axisLine: {
        show: false
      }
    },
    yAxis: {
      type: "value",
      // 去除刻度
      axisTick: {
        show: false
      },
      // 修饰刻度标签的颜色
      axisLabel: {
        color: "rgba(255,255,255,.7)"
      },
      // 修改y轴分割线的颜色
      splitLine: {
        lineStyle: {
          color: "#012f4a"
        }
      }
    },
    series: [{
      name: "平均训练成绩",
      type: "line",
      // 是否让线条圆滑显示
      smooth: true,
      data: ['78', '89', '89', '99', '69', '78', '92', '56']
    }]
  };
  // 3. 把配置和数据给实例对象
  myChart.setOption(option);

  // 重新把配置好的新数据给实例对象
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();
// 折线图定制
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#assess"));

  // (1)准备数据
  var data = {
    year: [
      [24, 40, 101, 134, 90, 230, 210, 230, 120, 230, 210, 120],
      [40, 64, 191, 324, 290, 330, 310, 213, 180, 200, 180, 79],
      [60, 88, 151, 194, 250, 300, 310, 323, 270, 230, 200, 190],
      [50, 84, 121, 224, 290, 330, 300, 300, 280, 260, 220, 150]
    ]
  };

  // 2. 指定配置和数据
  var option = {
    color: ["#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94"],
    tooltip: {
      // 通过坐标轴来触发
      trigger: "axis"
    },
    legend: {
      // 距离容器10%
      right: "10%",
      // 修饰图例文字的颜色
      textStyle: {
        color: "#4c9bfd"
      }
      // 如果series 里面设置了name，此时图例组件的data可以省略
      // data: ["邮件营销", "联盟广告"]
    },
    grid: {
      top: "20%",
      left: "3%",
      right: "4%",
      bottom: "3%",
      show: true,
      borderColor: "#012f4a",
      containLabel: true
    },

    xAxis: {
      type: "category",
      boundaryGap: false,
      data: [
        "1月",
        "2月",
        "3月",
        "4月",
        "5月",
        "6月",
        "7月",
        "8月",
        "9月",
        "10月",
        "11月",
        "12月"
      ],
      // 去除刻度
      axisTick: {
        show: false
      },
      // 修饰刻度标签的颜色
      axisLabel: {
        color: "rgba(255,255,255,.7)"
      },
      // 去除x坐标轴的颜色
      axisLine: {
        show: false
      }
    },
    yAxis: {
      type: "value",
      // 去除刻度
      axisTick: {
        show: false
      },
      // 修饰刻度标签的颜色
      axisLabel: {
        color: "rgba(255,255,255,.7)"
      },
      // 修改y轴分割线的颜色
      splitLine: {
        lineStyle: {
          color: "#012f4a"
        }
      }
    },
    series: [{
        name: "优秀",
        type: "line",
        // 是否让线条圆滑显示
        smooth: true,
        data: data.year[0]
      },
      {
        name: "称职",
        type: "line",
        smooth: true,
        data: data.year[1]
      },
      {
        name: "基本称职",
        type: "line",
        smooth: true,
        data: data.year[2]
      },
      {
        name: "不称职",
        type: "line",
        smooth: true,
        data: data.year[3]
      }
    ]
  };
  // 3. 把配置和数据给实例对象
  myChart.setOption(option);

  // 重新把配置好的新数据给实例对象
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();

(function () {
  var myChart = echarts.init(document.querySelector(".bar1 .chart"));
  var dataBJ = [
    [74, 49, 77, 1.46, 48, 27, 7],
    [78, 55, 80, 1.29, 59, 29, 8],
    [267, 216, 280, 4.8, 108, 64, 9],
    [108, 79, 120, 1.7, 75, 41, 14],
    [108, 63, 116, 1.48, 44, 26, 15],
    [94, 66, 110, 1.54, 62, 31, 17],
    [186, 142, 192, 3.88, 93, 79, 18],
    [42, 27, 43, 1, 53, 22, 25],
    [154, 117, 157, 3.05, 92, 58, 26],
    [52, 24, 60, 1.03, 50, 21, 30]
  ];

  var lineStyle = {
    normal: {
      width: 1,
      opacity: 0.5
    }
  };

  option = {
    grid: {
      top: "25%",
    },
    radar: {
      axisLabel: {
        fontSize: "10px"
      },
      indicator: [{
          name: 'AQI',
          max: 300
        },
        {
          name: 'PM2.5',
          max: 250
        },
        {
          name: 'PM10',
          max: 300
        },
        {
          name: 'CO',
          max: 5
        },
        {
          name: 'NO2',
          max: 200
        },
        {
          name: 'SO2',
          max: 100
        }
      ],
      shape: 'circle',
      splitNumber: 5,
      name: {
        textStyle: {
          color: 'rgb(238, 197, 102)'
        }
      },
      splitLine: {
        lineStyle: {
          color: [
            'rgba(238, 197, 102, 0.1)', 'rgba(238, 197, 102, 0.2)',
            'rgba(238, 197, 102, 0.4)', 'rgba(238, 197, 102, 0.6)',
            'rgba(238, 197, 102, 0.8)', 'rgba(238, 197, 102, 1)'
          ].reverse()
        }
      },
      splitArea: {
        show: false
      },
      axisLine: {
        lineStyle: {
          color: 'rgba(238, 197, 102, 0.5)'
        }
      }
    },
    series: [{
      name: '北京',
      type: 'radar',
      lineStyle: lineStyle,
      data: dataBJ,
      symbol: 'none',
      itemStyle: {
        color: '#FFFFE0'
      },
      areaStyle: {
        opacity: 0.1
      }
    }]
  };
  // 3. 把配置和数据给实例对象
  myChart.setOption(option);

  // 重新把配置好的新数据给实例对象
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();

//学习教育1
(function () {
  var myChart = echarts.init(document.querySelector("#edu_1"));
  option = {
    title: {
      text: '活跃度和平均分',
      textStyle: {
        color: "#ffffff",
        fontSize: 10
      },
      left: '45%',
      top: 0
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '0%',
      top: '15%',
      right: '0%',
      bottom: '4%',
      containLabel: true
    },
    xAxis: [{
      type: 'category',
      data: ['一', '二', '三', '四', '五'],
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1)",
          width: 1,
          type: "solid"
        },
      },
      axisTick: {
        show: false,
      },
      axisLabel: {
        interval: 0,
        // rotate:50,
        show: true,
        splitNumber: 15,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '7',
        },
      },
    }],
    yAxis: [{
      type: 'value',
      axisLabel: {
        //formatter: '{value} %'
        show: true,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '12',
        },
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1	)",
          width: 1,
          type: "solid"
        },
      },
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)",
        }
      }
    }],
    series: [{
        type: 'bar',
        data: [1500, 1200, 600, 700, 900],
        barWidth: '35%', //柱子宽度
        // barGap: 1, //柱子之间间距
        itemStyle: {
          normal: {
            color: '#27d08a',
            opacity: 1,
            barBorderRadius: 5,
          }
        }
      }

    ]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });

})();

// 学习教育2
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#edu_2"));

  option = {
    title: {
      text: '参加考试人数及比例',
      textStyle: {
        color: "#ffffff",
        fontSize: 10
      },
      left: 'center',
      bottom: 0
    },
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      position: function (p) {
        //其中p为当前鼠标的位置
        return [p[0] + 10, p[1] - 10];
      }
    },
    series: [{
      name: "年龄分布",
      type: "pie",
      center: ["50%", "42%"],
      radius: ["50%", "70%"],
      color: [
        "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94","#FFFF00"
      ],
      label: {
        show: false
      },
      labelLine: {
        show: false
      },
      data: [{
          value: 1,
          name: "0岁以下"
        },
        {
          value: 4,
          name: "20-29岁"
        },
        {
          value: 2,
          name: "30-39岁"
        },
        {
          value: 2,
          name: "40-49岁"
        },
        {
          value: 1,
          name: "50岁以上"
        }
      ]
    }]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();


(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#edu_3"));

  option = {
    title: {
      text: '及格人数及比例',
      textStyle: {
        color: "#ffffff",
        fontSize: 10
      },
      left: 'center',
      bottom: 0
    },
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      position: function (p) {
        //其中p为当前鼠标的位置
        return [p[0] + 10, p[1] - 10];
      }
    },
    series: [{
      name: "年龄分布",
      type: "pie",
      center: ["50%", "42%"],
      radius: ["50%", "70%"],
      color: [
        "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94","#FFFF00"
      ],
      label: {
        show: false
      },
      labelLine: {
        show: false
      },
      data: [{
          value: 1,
          name: "0岁以下"
        },
        {
          value: 4,
          name: "20-29岁"
        },
        {
          value: 2,
          name: "30-39岁"
        },
        {
          value: 2,
          name: "40-49岁"
        },
        {
          value: 1,
          name: "50岁以上"
        }
      ]
    }]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();

(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.querySelector("#edu_4"));

  option = {
    title: {
      text: '学习情况分布',
      textStyle: {
        color: "#ffffff",
        fontSize: 10
      },
      left: 'center',
      bottom: 0
    },
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      position: function (p) {
        //其中p为当前鼠标的位置
        return [p[0] + 10, p[1] - 10];
      }
    },
    series: [{
      name: "年龄分布",
      type: "pie",
      center: ["50%", "42%"],
      radius: ["50%", "70%"],
      color: [
        "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94","#FFFF00"
      ],
      label: {
        show: false
      },
      labelLine: {
        show: false
      },
      data: [{
          value: 1,
          name: "0岁以下"
        },
        {
          value: 4,
          name: "20-29岁"
        },
        {
          value: 2,
          name: "30-39岁"
        },
        {
          value: 2,
          name: "40-49岁"
        },
        {
          value: 1,
          name: "50岁以上"
        }
      ]
    }]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();

// 智慧党建
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.getElementById('dj3'));


  option = {
    //  backgroundColor: '#00265f',
    title: [{
      text: '组织生活',
      left: 'center',
      textStyle: {
        color: '#fff',
        fontSize:'10'
      }

    }],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '0%',
      top:'10px',
      right: '0%',
      bottom: '4%',
      containLabel: true
    },
    xAxis: [{
      type: 'category',
      data: ['武汉支队', '宜昌支队', '荆州支队', '孝感支队', '黄冈支队', '十堰支队', '汉江支队'],
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1)",
          width: 1,
          type: "solid"
        },
      },

      axisTick: {
        show: false,
      },
      axisLabel:  {
        interval: 0,
        // rotate:50,
        show: true,
        splitNumber: 15,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
    }],
    yAxis: [{
      name: "日期", //坐标名字
      nameLocation: "start",//坐标位置，支持start,end，middle
      nameTextStyle: {//字体样式
        color: "rgba(255,255,255,.6)",
        fontSize: 6,//字体大小
      },
      type: 'value',
      axisLabel: {
        //formatter: '{value} %'
        show:true,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1	)",
          width: 1,
          type: "solid"
        },
      },
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)",
        }
      }
    }],
    series: [
      {
        type: 'bar',
        data: [10, 9, 8, 6, 6, 4, 2],
        barWidth:'35%', //柱子宽度
        // barGap: 1, //柱子之间间距
        itemStyle: {
          normal: {
            color: function(params) {
              var colorList = [
                "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94",'#27727B',
                '#7FFF00','#FFFF00','#FAD860','#F3A43B','#60C0DD',
                '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
              ];
              return colorList[params.dataIndex]
            },
            opacity: 1,
            barBorderRadius: 5,
          }
        }
      }

    ]
  };
  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize",function(){
    myChart.resize();
  });
})();
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.getElementById('dj2'));


  option = {
    title: [{
      text: '党员占比',
      left: 'center',
      textStyle: {
        color: '#fff',
        fontSize:'10'
      }

    }],
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      left: 'right',
      icon:"circle",
      itemWidth:8,
      itemHeight:8,
      data: ['党员', '入党积极分子','其他'],
      textStyle: { //图例文字的样式
        color: '#fff',
        fontSize: 6
      },
    },
    series: [
      {
        name: '访问来源',
        type: 'pie',
        radius: '55%',
        center: ['50%', '60%'],
        data: [
          {value: 335, name: '党员'},
          {value: 310, name: '入党积极分子'},
          {value: 234, name: '其他'},
        ],
        label: {
          textStyle: {
            fontSize: 8
          }

        },
        color:["#00f2f1", "#ed3f35", "#7FFF00"],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize",function(){
    myChart.resize();
  });
})();
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.getElementById('dj4'));


  option = {
    //  backgroundColor: '#00265f',
    title: [{
      text: '积分排名',
      left: 'center',
      textStyle: {
        color: '#fff',
        fontSize:'10'
      }

    }],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '0%',
      top:'10px',
      right: '0%',
      bottom: '4%',
      containLabel: true
    },
    yAxis: [{
      type: 'category',
      data: ['武汉支队', '宜昌支队', '荆州支队', '孝感支队', '黄冈支队', '十堰支队', '汉江支队'],
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1)",
          width: 1,
          type: "solid"
        },
      },

      axisTick: {
        show: false,
      },
      axisLabel:  {
        interval: 0,
        // rotate:50,
        show: true,
        splitNumber: 15,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
      inverse: true
    }],
    xAxis: [{
      name: "日期", //坐标名字
      nameLocation: "start",//坐标位置，支持start,end，middle
      nameTextStyle: {//字体样式
        color: "rgba(255,255,255,.6)",
        fontSize: 6,//字体大小
      },
      type: 'value',
      axisLabel: {
        //formatter: '{value} %'
        show:true,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1	)",
          width: 1,
          type: "solid"
        },
      },
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)",
        }
      }
    }],
    series: [
      {
        type: 'bar',
        data: [10, 9, 8, 6, 6, 4, 2],
        barWidth:'35%', //柱子宽度
        // barGap: 1, //柱子之间间距
        itemStyle: {
          normal: {
            color: function(params) {
              var colorList = [
                "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94",'#27727B',
                '#7FFF00','#FFFF00','#FAD860','#F3A43B','#60C0DD',
                '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
              ];
              return colorList[params.dataIndex]
            },
            opacity: 1,
            barBorderRadius: 5,
          }
        }
      }

    ]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize",function(){
    myChart.resize();
  });
})();
(function () {
  // 基于准备好的dom，初始化echarts实例
  var myChart = echarts.init(document.getElementById('dj1'));

  option = {
    //  backgroundColor: '#00265f',
    title: [{
      text: '主题党日',
      left: 'center',
      textStyle: {
        color: '#fff',
        fontSize:'10'
      }

    }],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '0%',
      top:'10px',
      right: '0%',
      bottom: '4%',
      containLabel: true
    },
    xAxis: [{
      type: 'category',
      data: ['武汉支队', '宜昌支队', '荆州支队', '孝感支队', '黄冈支队', '十堰支队', '汉江支队'],
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1)",
          width: 1,
          type: "solid"
        },
      },

      axisTick: {
        show: false,
      },
      axisLabel:  {
        interval: 0,
        // rotate:50,
        show: true,
        splitNumber: 15,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
    }],
    yAxis: [{
      name: "日期", //坐标名字
      nameLocation: "start",//坐标位置，支持start,end，middle
      nameTextStyle: {//字体样式
        color: "rgba(255,255,255,.6)",
        fontSize: 6,//字体大小
      },
      type: 'value',
      axisLabel: {
        //formatter: '{value} %'
        show:true,
        textStyle: {
          color: "rgba(255,255,255,.6)",
          fontSize: '6',
        },
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "rgba(255,255,255,.1	)",
          width: 1,
          type: "solid"
        },
      },
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,.1)",
        }
      }
    }],
    series: [
      {
        type: 'bar',
        data: [10, 9, 8, 6, 6, 4, 2],
        barWidth:'35%', //柱子宽度
        // barGap: 1, //柱子之间间距
        itemStyle: {
          normal: {
            color: function(params) {
              var colorList = [
                "#00f2f1", "#ed3f35", "#BBFFFF", "#4EEE94",'#27727B',
                '#7FFF00','#FFFF00','#FAD860','#F3A43B','#60C0DD',
                '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
              ];
              return colorList[params.dataIndex]
            },
            opacity: 1,
            barBorderRadius: 5,
          }
        }
      }

    ]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);
  window.addEventListener("resize", function () {
    myChart.resize();
  });
})();